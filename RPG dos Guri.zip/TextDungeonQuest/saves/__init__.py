"""
Package for save game files.
"""
