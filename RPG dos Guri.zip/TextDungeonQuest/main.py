#!/usr/bin/env python3
"""
Main entry point for the text-based RPG game.
"""
import os
import sys
import time
import json
from game.ui import UI
from game.game_state import GameState
from game.character import Player
from game.world import World

def main():
    """
    Main function to start the game.
    """
    ui = UI()
    ui.show_title_screen()
    
    choice = ui.main_menu()
    
    game_state = GameState()
    world = World()
    
    if choice == "1":  # New Game
        player_name = ui.get_player_name()
        player_class = ui.choose_character_class()
        player = Player(player_name, player_class)
        game_state.player = player
        ui.display_message(f"Welcome, {player_name} the {player_class}!")
        ui.display_message("Your adventure begins now...")
        time.sleep(1)
        
    elif choice == "2":  # Load Game
        saves = game_state.get_save_files()
        if not saves:
            ui.display_message("No save files found. Starting new game...")
            player_name = ui.get_player_name()
            player_class = ui.choose_character_class()
            player = Player(player_name, player_class)
            game_state.player = player
            ui.display_message(f"Welcome, {player_name} the {player_class}!")
            ui.display_message("Your adventure begins now...")
            time.sleep(1)
        else:
            save_choice = ui.load_game_menu(saves)
            if save_choice == "0":
                ui.display_message("Returning to main menu...")
                return main()
            else:
                save_index = int(save_choice) - 1
                if 0 <= save_index < len(saves):
                    game_state.load_game(saves[save_index])
                    ui.display_message(f"Welcome back, {game_state.player.name} the {game_state.player.character_class}!")
                    ui.display_message("Your adventure continues...")
                    time.sleep(1)
                else:
                    ui.display_message("Invalid choice. Returning to main menu...")
                    return main()
    
    elif choice == "3":  # Exit
        ui.display_message("Thanks for playing! Goodbye.")
        sys.exit(0)
    
    # Main game loop
    try:
        while True:
            current_location = world.get_location(game_state.player.location)
            ui.display_location(current_location)
            
            action = ui.game_menu(current_location)
            
            if action == "explore":
                event = world.generate_event(game_state.player)
                ui.handle_event(event, game_state)
                
            elif action == "rest":
                healing = game_state.player.max_health // 4
                game_state.player.health = min(game_state.player.max_health, game_state.player.health + healing)
                ui.display_message(f"You rest and recover {healing} health. Current health: {game_state.player.health}/{game_state.player.max_health}")
                
            elif action == "inventory":
                ui.show_inventory(game_state.player)
                
            elif action == "stats":
                ui.show_player_stats(game_state.player)
                
            elif action == "move":
                destinations = world.get_connected_locations(game_state.player.location)
                new_location = ui.choose_destination(destinations)
                if new_location:
                    game_state.player.location = new_location
                    ui.display_message(f"Traveling to {world.get_location(new_location)['name']}...")
                    time.sleep(1)
                
            elif action == "save":
                save_name = ui.get_save_name()
                if save_name:
                    game_state.save_game(save_name)
                    ui.display_message(f"Game saved as '{save_name}'.")
                
            elif action == "exit":
                ui.display_message("Returning to main menu...")
                return main()
    except KeyboardInterrupt:
        ui.display_message("\nGame interrupted. Would you like to save before exiting?")
        if ui.yes_no_question():
            save_name = ui.get_save_name()
            if save_name:
                game_state.save_game(save_name)
                ui.display_message(f"Game saved as '{save_name}'.")
        ui.display_message("Thanks for playing! Goodbye.")
        sys.exit(0)

if __name__ == "__main__":
    # Create saves directory if it doesn't exist
    os.makedirs("saves", exist_ok=True)
    main()
