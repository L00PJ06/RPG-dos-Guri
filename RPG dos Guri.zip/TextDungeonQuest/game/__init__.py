"""
Game package initialization.
"""
