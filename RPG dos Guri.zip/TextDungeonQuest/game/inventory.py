"""
Inventory system for the RPG game.
"""

class Inventory:
    """
    Inventory class that holds items for player.
    """
    
    def __init__(self, max_items=20):
        """Initialize inventory with maximum capacity."""
        self.items = []
        self.max_items = max_items
    
    def add_item(self, item):
        """
        Add an item to the inventory if there's room.
        
        Args:
            item (dict): The item to add.
            
        Returns:
            bool: True if item was added, False if inventory is full.
        """
        if len(self.items) >= self.max_items:
            return False
        
        self.items.append(item)
        return True
    
    def remove_item(self, item):
        """
        Remove an item from the inventory.
        
        Args:
            item (dict): The item to remove.
            
        Returns:
            bool: True if item was removed, False if item wasn't found.
        """
        for i, inv_item in enumerate(self.items):
            if inv_item["name"] == item["name"]:
                self.items.pop(i)
                return True
        return False
    
    def get_item(self, item_name):
        """
        Get an item by name.
        
        Args:
            item_name (str): The name of the item to get.
            
        Returns:
            dict: The item if found, None otherwise.
        """
        for item in self.items:
            if item["name"] == item_name:
                return item
        return None
    
    def get_items_by_type(self, item_type):
        """
        Get all items of a specific type.
        
        Args:
            item_type (str): The type of items to get.
            
        Returns:
            list: List of items matching the type.
        """
        return [item for item in self.items if item["type"] == item_type]
    
    def is_full(self):
        """
        Check if inventory is full.
        
        Returns:
            bool: True if inventory is full, False otherwise.
        """
        return len(self.items) >= self.max_items
    
    def to_dict(self):
        """
        Convert inventory to dictionary for saving.
        
        Returns:
            dict: Dictionary representation of inventory.
        """
        return {
            "items": self.items,
            "max_items": self.max_items
        }
    
    @classmethod
    def from_dict(cls, data):
        """
        Create inventory from dictionary.
        
        Args:
            data (dict): Dictionary containing inventory data.
            
        Returns:
            Inventory: New inventory instance.
        """
        inventory = cls(data.get("max_items", 20))
        inventory.items = data.get("items", [])
        return inventory
