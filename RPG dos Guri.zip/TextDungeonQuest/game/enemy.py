"""
Enemy classes for the RPG game.
"""
from game.dice import Dice
import random

class Enemy:
    """Base enemy class."""
    
    def __init__(self, name, level=1):
        """Initialize an enemy with default stats based on level."""
        self.name = name
        self.character_class = "Enemy"
        self.level = level
        self.health = 10 + (level * 2)
        self.max_health = self.health
        self.strength = 3 + level
        self.dexterity = 2 + level
        self.intelligence = 1 + level
        self.constitution = 2 + level
        self.attack_dice = Dice(6)  # d6 by default
        self.defense_dice = Dice(4)  # d4 by default
        self.experience_value = 10 * level
        self.skills = []
    
    def is_alive(self):
        """Check if enemy is alive."""
        return self.health > 0
    
    def take_damage(self, amount):
        """Apply damage to the enemy."""
        self.health -= amount
        if self.health < 0:
            self.health = 0
        return amount
    
    def heal(self, amount):
        """Heal the enemy."""
        old_health = self.health
        self.health += amount
        if self.health > self.max_health:
            self.health = self.max_health
        return self.health - old_health

class Goblin(Enemy):
    """Goblin enemy class."""
    
    def __init__(self, level=1):
        super().__init__("Goblin", level)
        self.health = 8 + (level * 2)
        self.max_health = self.health
        self.strength = 2 + level
        self.dexterity = 4 + level
        self.attack_dice = Dice(4)  # d4
        self.defense_dice = Dice(4)  # d4
        self.skills = ["Scurry"]

class Orc(Enemy):
    """Orc enemy class."""
    
    def __init__(self, level=2):
        super().__init__("Orc", level)
        self.health = 12 + (level * 3)
        self.max_health = self.health
        self.strength = 5 + level
        self.dexterity = 2 + level
        self.constitution = 4 + level
        self.attack_dice = Dice(8)  # d8
        self.defense_dice = Dice(6)  # d6
        self.skills = ["Rage"]

class Skeleton(Enemy):
    """Skeleton enemy class."""
    
    def __init__(self, level=1):
        super().__init__("Skeleton", level)
        self.health = 7 + (level * 2)
        self.max_health = self.health
        self.strength = 3 + level
        self.dexterity = 3 + level
        self.constitution = 1 + level  # Undead have low constitution
        self.attack_dice = Dice(6)  # d6
        self.defense_dice = Dice(4)  # d4
        self.skills = ["Bone Rattle"]

class Necromancer(Enemy):
    """Necromancer enemy class."""
    
    def __init__(self, level=3):
        super().__init__("Necromancer", level)
        self.health = 10 + (level * 2)
        self.max_health = self.health
        self.strength = 1 + level
        self.dexterity = 2 + level
        self.intelligence = 5 + level
        self.constitution = 2 + level
        self.attack_dice = Dice(6)  # d6
        self.defense_dice = Dice(4)  # d4
        self.skills = ["Dark Bolt", "Summon Undead"]

class Dragon(Enemy):
    """Dragon enemy class (boss)."""
    
    def __init__(self, level=5):
        super().__init__("Dragon", level)
        self.health = 25 + (level * 5)
        self.max_health = self.health
        self.strength = 7 + level
        self.dexterity = 4 + level
        self.intelligence = 6 + level
        self.constitution = 8 + level
        self.attack_dice = Dice(12)  # d12
        self.defense_dice = Dice(10)  # d10
        self.experience_value = 50 * level
        self.skills = ["Fire Breath", "Tail Swipe", "Wing Gust"]

def create_random_enemy(player_level):
    """Create a random enemy based on player level."""
    level_range = [max(1, player_level - 1), player_level, min(10, player_level + 1)]
    enemy_level = random.choice(level_range)
    
    enemy_types = [
        (Goblin, 0.3),     # 30% chance for Goblin
        (Orc, 0.25),       # 25% chance for Orc
        (Skeleton, 0.25),  # 25% chance for Skeleton
        (Necromancer, 0.15),  # 15% chance for Necromancer
        (Dragon, 0.05)     # 5% chance for Dragon
    ]
    
    # Ensure Dragon only appears for players level 3 or higher
    if player_level < 3:
        enemy_types = enemy_types[:-1]  # Remove Dragon
        # Redistribute probabilities
        total = sum(prob for _, prob in enemy_types)
        enemy_types = [(enemy, prob/total) for enemy, prob in enemy_types]
    
    # Weighted random choice
    r = random.random()
    cumulative = 0
    for enemy_class, probability in enemy_types:
        cumulative += probability
        if r <= cumulative:
            return enemy_class(enemy_level)
    
    # Fallback
    return Goblin(enemy_level)
