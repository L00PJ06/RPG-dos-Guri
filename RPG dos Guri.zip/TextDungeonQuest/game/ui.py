"""
User interface for the RPG game.
"""
import os
import sys
import time
from datetime import datetime
try:
    import pyfiglet
    PYFIGLET_AVAILABLE = True
except ImportError:
    PYFIGLET_AVAILABLE = False

try:
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
    from rich.text import Text
    RICH_AVAILABLE = True
except ImportError:
    RICH_AVAILABLE = False

from game.combat import Combat
from game.enemy import create_random_enemy

class UI:
    """User interface for the RPG game."""
    
    def __init__(self):
        """Initialize the UI."""
        self.clear_screen()
        
        # Set up Rich console if available
        if RICH_AVAILABLE:
            self.console = Console()
        else:
            self.console = None
    
    def clear_screen(self):
        """Clear the terminal screen."""
        os.system('cls' if os.name == 'nt' else 'clear')
    
    def show_title_screen(self):
        """Display the game title screen."""
        self.clear_screen()
        
        if PYFIGLET_AVAILABLE:
            title = pyfiglet.figlet_format("Epic Quest", font="big")
            subtitle = pyfiglet.figlet_format("Text RPG Adventure", font="small")
            print(title)
            print(subtitle)
        else:
            print("=" * 60)
            print("=" * 20 + " EPIC QUEST " + "=" * 20)
            print("=" * 15 + " Text RPG Adventure " + "=" * 15)
            print("=" * 60)
        
        print("\nWelcome to Epic Quest, a text-based RPG adventure!")
        print("Embark on a journey through a land of magic and danger.")
        print("\nPress Enter to continue...")
        input()
    
    def main_menu(self):
        """Show the main menu and get player choice."""
        self.clear_screen()
        
        if RICH_AVAILABLE:
            self.console.print(Panel.fit("Main Menu", style="bold green"))
            self.console.print("[1] New Game")
            self.console.print("[2] Load Game")
            self.console.print("[3] Exit")
        else:
            print("=" * 20)
            print("MAIN MENU")
            print("=" * 20)
            print("1. New Game")
            print("2. Load Game")
            print("3. Exit")
        
        while True:
            choice = input("\nEnter your choice (1-3): ")
            if choice in ["1", "2", "3"]:
                return choice
            else:
                self.display_message("Invalid choice. Please try again.")
    
    def get_player_name(self):
        """Get the player's name."""
        self.clear_screen()
        
        if RICH_AVAILABLE:
            self.console.print(Panel.fit("Character Creation", style="bold blue"))
            self.console.print("What is your name, adventurer?")
        else:
            print("=" * 20)
            print("CHARACTER CREATION")
            print("=" * 20)
            print("What is your name, adventurer?")
        
        while True:
            name = input("> ").strip()
            if name:
                return name
            else:
                self.display_message("You must enter a name.")
    
    def choose_character_class(self):
        """Let the player choose a character class."""
        self.clear_screen()
        
        classes = {
            "1": "Warrior",
            "2": "Mage",
            "3": "Rogue"
        }
        
        descriptions = {
            "Warrior": "Strong and tough. Uses weapons and armor to great effect.",
            "Mage": "Intelligent and wise. Uses powerful spells to defeat enemies.",
            "Rogue": "Quick and agile. Uses stealth and cunning to overcome obstacles."
        }
        
        if RICH_AVAILABLE:
            self.console.print(Panel.fit("Choose Your Class", style="bold blue"))
            
            table = Table(title="Available Classes")
            table.add_column("Choice", style="cyan")
            table.add_column("Class", style="green")
            table.add_column("Description", style="yellow")
            
            for key, class_name in classes.items():
                table.add_row(key, class_name, descriptions[class_name])
            
            self.console.print(table)
        else:
            print("=" * 20)
            print("CHOOSE YOUR CLASS")
            print("=" * 20)
            
            for key, class_name in classes.items():
                print(f"{key}. {class_name}: {descriptions[class_name]}")
        
        while True:
            choice = input("\nEnter your choice (1-3): ")
            if choice in classes:
                return classes[choice]
            else:
                self.display_message("Invalid choice. Please try again.")
    
    def load_game_menu(self, save_files):
        """Show the load game menu and get player choice."""
        self.clear_screen()
        
        if not save_files:
            self.display_message("No save files found.")
            return None
        
        from game.game_state import GameState
        game_state = GameState()
        
        if RICH_AVAILABLE:
            self.console.print(Panel.fit("Load Game", style="bold blue"))
            
            table = Table(title="Available Save Files")
            table.add_column("Choice", style="cyan")
            table.add_column("Save Name", style="green")
            table.add_column("Character", style="yellow")
            table.add_column("Level", style="magenta")
            table.add_column("Date", style="blue")
            
            for i, save_path in enumerate(save_files, 1):
                save_info = game_state.get_save_info(save_path)
                if save_info:
                    table.add_row(
                        str(i),
                        save_info["save_name"],
                        f"{save_info['player_name']} ({save_info['player_class']})",
                        str(save_info["player_level"]),
                        save_info["timestamp"]
                    )
            
            self.console.print(table)
            self.console.print("[0] Back to Main Menu")
        else:
            print("=" * 20)
            print("LOAD GAME")
            print("=" * 20)
            
            for i, save_path in enumerate(save_files, 1):
                save_info = game_state.get_save_info(save_path)
                if save_info:
                    print(f"{i}. {save_info['save_name']} - "
                          f"{save_info['player_name']} ({save_info['player_class']}) "
                          f"Level {save_info['player_level']} - "
                          f"{save_info['timestamp']}")
            
            print("0. Back to Main Menu")
        
        while True:
            choice = input("\nEnter your choice: ")
            if choice == "0":
                return "0"
            elif choice.isdigit() and 1 <= int(choice) <= len(save_files):
                return choice
            else:
                self.display_message("Invalid choice. Please try again.")
    
    def display_message(self, message):
        """Display a message to the player."""
        if RICH_AVAILABLE:
            self.console.print(message)
        else:
            print(message)
    
    def display_location(self, location):
        """Display information about the current location."""
        self.clear_screen()
        
        if RICH_AVAILABLE:
            title = Text(location["name"], style="bold green")
            self.console.print(Panel(location["description"], title=title))
        else:
            print("=" * 60)
            print(f"{location['name']}")
            print("=" * 60)
            print(location["description"])
            print("")
    
    def game_menu(self, location):
        """Show the in-game menu and get player action."""
        if RICH_AVAILABLE:
            self.console.print(Panel.fit("What would you like to do?", style="bold cyan"))
            self.console.print("[1] Explore the area")
            self.console.print("[2] Rest and recover")
            self.console.print("[3] Check inventory")
            self.console.print("[4] View character stats")
            self.console.print("[5] Travel to another location")
            self.console.print("[6] Save game")
            self.console.print("[7] Exit to main menu")
        else:
            print("\nWhat would you like to do?")
            print("1. Explore the area")
            print("2. Rest and recover")
            print("3. Check inventory")
            print("4. View character stats")
            print("5. Travel to another location")
            print("6. Save game")
            print("7. Exit to main menu")
        
        actions = {
            "1": "explore",
            "2": "rest",
            "3": "inventory",
            "4": "stats",
            "5": "move",
            "6": "save",
            "7": "exit"
        }
        
        while True:
            choice = input("\nEnter your choice (1-7): ")
            if choice in actions:
                return actions[choice]
            else:
                self.display_message("Invalid choice. Please try again.")
    
    def combat_menu(self, actions):
        """Show the combat menu and get player action."""
        if RICH_AVAILABLE:
            self.console.print(Panel.fit("Combat Actions", style="bold red"))
            for i, action in enumerate(actions, 1):
                self.console.print(f"[{i}] {action}")
        else:
            print("\nCombat Actions:")
            for i, action in enumerate(actions, 1):
                print(f"{i}. {action}")
        
        while True:
            choice = input("\nEnter your choice: ")
            if choice.isdigit() and 1 <= int(choice) <= len(actions):
                return choice
            else:
                self.display_message("Invalid choice. Please try again.")
    
    def choose_skill(self, skills):
        """Let the player choose a skill to use."""
        if not skills:
            self.display_message("You don't have any skills yet.")
            return None
        
        if RICH_AVAILABLE:
            self.console.print(Panel.fit("Choose a Skill", style="bold magenta"))
            for i, skill in enumerate(skills, 1):
                self.console.print(f"[{i}] {skill}")
            self.console.print("[0] Back")
        else:
            print("\nChoose a Skill:")
            for i, skill in enumerate(skills, 1):
                print(f"{i}. {skill}")
            print("0. Back")
        
        while True:
            choice = input("\nEnter your choice: ")
            if choice == "0":
                return None
            elif choice.isdigit() and 1 <= int(choice) <= len(skills):
                return skills[int(choice) - 1]
            else:
                self.display_message("Invalid choice. Please try again.")
    
    def choose_item(self, items):
        """Let the player choose an item to use."""
        if not items:
            self.display_message("You don't have any items.")
            return None
        
        usable_items = [item for item in items if item["type"] == "consumable"]
        if not usable_items:
            self.display_message("You don't have any usable items.")
            return None
        
        if RICH_AVAILABLE:
            self.console.print(Panel.fit("Choose an Item", style="bold yellow"))
            for i, item in enumerate(usable_items, 1):
                self.console.print(f"[{i}] {item['name']}")
            self.console.print("[0] Back")
        else:
            print("\nChoose an Item:")
            for i, item in enumerate(usable_items, 1):
                print(f"{i}. {item['name']}")
            print("0. Back")
        
        while True:
            choice = input("\nEnter your choice: ")
            if choice == "0":
                return None
            elif choice.isdigit() and 1 <= int(choice) <= len(usable_items):
                return usable_items[int(choice) - 1]
            else:
                self.display_message("Invalid choice. Please try again.")
    
    def choose_destination(self, destinations):
        """Let the player choose a destination to travel to."""
        if not destinations:
            self.display_message("There are no connected locations.")
            return None
        
        if RICH_AVAILABLE:
            self.console.print(Panel.fit("Choose a Destination", style="bold blue"))
            for i, dest in enumerate(destinations, 1):
                self.console.print(f"[{i}] {dest['name']}")
            self.console.print("[0] Stay here")
        else:
            print("\nChoose a Destination:")
            for i, dest in enumerate(destinations, 1):
                print(f"{i}. {dest['name']}")
            print("0. Stay here")
        
        while True:
            choice = input("\nEnter your choice: ")
            if choice == "0":
                return None
            elif choice.isdigit() and 1 <= int(choice) <= len(destinations):
                return destinations[int(choice) - 1]["id"]
            else:
                self.display_message("Invalid choice. Please try again.")
    
    def get_save_name(self):
        """Get a name for the save file."""
        if RICH_AVAILABLE:
            self.console.print(Panel.fit("Save Game", style="bold green"))
            self.console.print("Enter a name for your save (or leave blank to cancel):")
        else:
            print("\nSAVE GAME")
            print("Enter a name for your save (or leave blank to cancel):")
        
        save_name = input("> ").strip()
        if save_name:
            return save_name
        return None
    
    def yes_no_question(self, question=None):
        """Ask a yes/no question and return the result."""
        if question:
            self.display_message(question)
        
        while True:
            response = input("(y/n): ").lower().strip()
            if response in ["y", "yes"]:
                return True
            elif response in ["n", "no"]:
                return False
            else:
                self.display_message("Please answer y or n.")
    
    def show_inventory(self, player):
        """Display the player's inventory."""
        self.clear_screen()
        
        if RICH_AVAILABLE:
            self.console.print(Panel.fit(f"{player.name}'s Inventory", style="bold yellow"))
            
            if not player.inventory.items:
                self.console.print("Your inventory is empty.")
            else:
                table = Table()
                table.add_column("Item", style="green")
                table.add_column("Type", style="blue")
                table.add_column("Value", style="yellow")
                
                for item in player.inventory.items:
                    table.add_row(
                        item["name"],
                        item["type"].capitalize(),
                        str(item["value"])
                    )
                
                self.console.print(table)
            
            self.console.print(f"Gold: {player.gold}")
        else:
            print("=" * 40)
            print(f"{player.name}'s Inventory")
            print("=" * 40)
            
            if not player.inventory.items:
                print("Your inventory is empty.")
            else:
                print(f"{'Item':<25} {'Type':<15} {'Value'}")
                print("-" * 50)
                
                for item in player.inventory.items:
                    print(f"{item['name']:<25} {item['type'].capitalize():<15} {item['value']}")
            
            print(f"\nGold: {player.gold}")
        
        input("\nPress Enter to continue...")
    
    def show_player_stats(self, player):
        """Display the player's stats."""
        self.clear_screen()
        
        if RICH_AVAILABLE:
            self.console.print(Panel.fit(f"{player.name} the {player.character_class}", style="bold green"))
            
            stats = Table()
            stats.add_column("Stat", style="cyan")
            stats.add_column("Value", style="yellow")
            
            stats.add_row("Level", str(player.level))
            stats.add_row("Experience", f"{player.experience}/{player.level * 100}")
            stats.add_row("Health", f"{player.health}/{player.max_health}")
            stats.add_row("Mana", f"{player.mana}/{player.max_mana}")
            stats.add_row("Strength", str(player.strength))
            stats.add_row("Dexterity", str(player.dexterity))
            stats.add_row("Intelligence", str(player.intelligence))
            stats.add_row("Constitution", str(player.constitution))
            stats.add_row("Attack Dice", str(player.attack_dice))
            stats.add_row("Defense Dice", str(player.defense_dice))
            
            self.console.print(stats)
            
            if player.skills:
                skills = ", ".join(player.skills)
                self.console.print(Panel(f"Skills: {skills}", title="Abilities"))
        else:
            print("=" * 40)
            print(f"{player.name} the {player.character_class}")
            print("=" * 40)
            
            print(f"Level: {player.level}")
            print(f"Experience: {player.experience}/{player.level * 100}")
            print(f"Health: {player.health}/{player.max_health}")
            print(f"Mana: {player.mana}/{player.max_mana}")
            print(f"Strength: {player.strength}")
            print(f"Dexterity: {player.dexterity}")
            print(f"Intelligence: {player.intelligence}")
            print(f"Constitution: {player.constitution}")
            print(f"Attack Dice: {player.attack_dice}")
            print(f"Defense Dice: {player.defense_dice}")
            
            if player.skills:
                print(f"\nSkills: {', '.join(player.skills)}")
        
        input("\nPress Enter to continue...")
    
    def handle_event(self, event, game_state):
        """Handle a random event."""
        if event["type"] == "enemy":
            self.display_message(f"You encounter a {event['enemy'].name}!")
            time.sleep(1)
            
            combat = Combat(game_state.player, event["enemy"], self)
            result = combat.start_combat()
            
            if not result:
                self.display_message("Game over!")
                if self.yes_no_question("Would you like to load a saved game?"):
                    save_files = game_state.get_save_files()
                    if not save_files:
                        self.display_message("No save files found. Starting a new game...")
                        time.sleep(2)
                        self.clear_screen()
                        os.execl(sys.executable, sys.executable, *sys.argv)
                    else:
                        save_choice = self.load_game_menu(save_files)
                        if save_choice == "0":
                            self.clear_screen()
                            os.execl(sys.executable, sys.executable, *sys.argv)
                        else:
                            save_index = int(save_choice) - 1
                            if 0 <= save_index < len(save_files):
                                game_state.load_game(save_files[save_index])
                                self.display_message(f"Welcome back, {game_state.player.name} the {game_state.player.character_class}!")
                                self.display_message("Your adventure continues...")
                                time.sleep(1)
                else:
                    self.clear_screen()
                    os.execl(sys.executable, sys.executable, *sys.argv)
        
        elif event["type"] == "treasure":
            self.display_message(f"You found a {event['item']['name']}!")
            if game_state.player.inventory.add_item(event["item"]):
                self.display_message(f"Added {event['item']['name']} to your inventory.")
            else:
                self.display_message("Your inventory is full. You left the item behind.")
            
            if "gold" in event:
                self.display_message(f"You also found {event['gold']} gold!")
                game_state.player.gold += event["gold"]
            
            time.sleep(1)
        
        elif event["type"] == "trap":
            self.display_message(f"You triggered a {event['name']}!")
            self.display_message(event["description"])
            
            damage = event["damage"]
            if damage > 0:
                game_state.player.take_damage(damage)
                self.display_message(f"You took {damage} damage! Health: {game_state.player.health}/{game_state.player.max_health}")
                
                if not game_state.player.is_alive():
                    self.display_message("You died!")
                    if self.yes_no_question("Would you like to load a saved game?"):
                        save_files = game_state.get_save_files()
                        if not save_files:
                            self.display_message("No save files found. Starting a new game...")
                            time.sleep(2)
                            self.clear_screen()
                            os.execl(sys.executable, sys.executable, *sys.argv)
                        else:
                            save_choice = self.load_game_menu(save_files)
                            if save_choice == "0":
                                self.clear_screen()
                                os.execl(sys.executable, sys.executable, *sys.argv)
                            else:
                                save_index = int(save_choice) - 1
                                if 0 <= save_index < len(save_files):
                                    game_state.load_game(save_files[save_index])
                                    self.display_message(f"Welcome back, {game_state.player.name} the {game_state.player.character_class}!")
                                    self.display_message("Your adventure continues...")
                                    time.sleep(1)
                    else:
                        self.clear_screen()
                        os.execl(sys.executable, sys.executable, *sys.argv)
                        
            time.sleep(1)
        
        elif event["type"] == "npc":
            self.display_message(f"You meet {event['name']}.")
            self.display_message(f'"{event["dialogue"]}"')
            
            if "quest" in event:
                if self.yes_no_question(f"Accept the quest from {event['name']}?"):
                    self.display_message(f"You accepted the quest: {event['quest']['name']}")
                    # Add quest handling logic here
                else:
                    self.display_message(f"You declined the quest.")
            
            time.sleep(1)
