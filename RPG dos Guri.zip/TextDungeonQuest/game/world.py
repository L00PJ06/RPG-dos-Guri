"""
World and location management for the RPG game.
"""
import random
from game.enemy import create_random_enemy

class World:
    """Manages the game world and locations."""
    
    def __init__(self):
        """Initialize the game world with locations."""
        self.locations = {
            "town": {
                "id": "town",
                "name": "Town of Aldor",
                "description": "A small but bustling town with cobblestone streets and thatched roof houses. "
                               "The town square is filled with merchants selling their wares, and the smell "
                               "of fresh bread wafts from the bakery.",
                "connections": ["forest", "mountains", "inn"],
                "safe": True
            },
            "inn": {
                "id": "inn",
                "name": "The Golden Stag Inn",
                "description": "A cozy inn with a roaring fireplace and the smell of ale and stew. "
                               "Travelers and locals alike gather here to share tales and seek refuge.",
                "connections": ["town"],
                "safe": True
            },
            "forest": {
                "id": "forest",
                "name": "Whispering Woods",
                "description": "A dense forest with towering trees that block out most of the sunlight. "
                               "The air is cool and damp, and you can hear strange noises coming from deep "
                               "within the woods.",
                "connections": ["town", "cave", "river"],
                "safe": False
            },
            "cave": {
                "id": "cave",
                "name": "Shadowdeep Caverns",
                "description": "A dark cave system that extends deep into the earth. Stalactites hang from "
                               "the ceiling, and the distant sound of dripping water echoes throughout. "
                               "This place feels dangerous.",
                "connections": ["forest"],
                "safe": False
            },
            "river": {
                "id": "river",
                "name": "Silverflow River",
                "description": "A wide, fast-flowing river with crystal clear water. Fish can be seen "
                               "swimming beneath the surface, and the riverbanks are lush with vegetation.",
                "connections": ["forest", "mountains"],
                "safe": False
            },
            "mountains": {
                "id": "mountains",
                "name": "Frostpeak Mountains",
                "description": "Towering mountains with snow-capped peaks that reach into the clouds. "
                               "The air is thin and cold here, and the path is treacherous. Beware of "
                               "the dangers that lurk in the heights.",
                "connections": ["town", "river", "temple"],
                "safe": False
            },
            "temple": {
                "id": "temple",
                "name": "Ancient Temple",
                "description": "A mysterious temple built long ago by a forgotten civilization. "
                               "The stone walls are covered in strange symbols and carvings. "
                               "A sense of ancient power permeates the air.",
                "connections": ["mountains"],
                "safe": False
            }
        }
    
    def get_location(self, location_id):
        """
        Get a location by ID.
        
        Args:
            location_id (str): The ID of the location.
            
        Returns:
            dict: The location data if found, None otherwise.
        """
        return self.locations.get(location_id, None)
    
    def get_connected_locations(self, location_id):
        """
        Get all locations connected to the given location.
        
        Args:
            location_id (str): The ID of the location.
            
        Returns:
            list: List of connected location data.
        """
        location = self.get_location(location_id)
        if not location:
            return []
        
        connected = []
        for conn_id in location["connections"]:
            conn_location = self.get_location(conn_id)
            if conn_location:
                connected.append(conn_location)
        
        return connected
    
    def generate_event(self, player):
        """
        Generate a random event based on the player's location.
        
        Args:
            player: The player character.
            
        Returns:
            dict: Event data.
        """
        location = self.get_location(player.location)
        
        # In safe locations, no enemies
        if location["safe"]:
            event_types = ["treasure", "npc"]
        else:
            # More danger in unsafe locations
            event_types = ["enemy", "enemy", "treasure", "trap", "npc"]
        
        event_type = random.choice(event_types)
        
        if event_type == "enemy":
            enemy = create_random_enemy(player.level)
            return {
                "type": "enemy",
                "enemy": enemy
            }
        elif event_type == "treasure":
            # Generate a random item
            item_types = ["weapon", "armor", "consumable"]
            item_type = random.choice(item_types)
            
            if item_type == "weapon":
                weapon_names = ["Sword", "Axe", "Dagger", "Mace", "Staff"]
                quality = ["Common", "Uncommon", "Rare"]
                name = f"{random.choice(quality)} {random.choice(weapon_names)}"
                value = random.randint(5, 20) * player.level
            elif item_type == "armor":
                armor_names = ["Helmet", "Chestplate", "Gauntlets", "Boots", "Shield"]
                quality = ["Common", "Uncommon", "Rare"]
                name = f"{random.choice(quality)} {random.choice(armor_names)}"
                value = random.randint(5, 15) * player.level
            else:  # consumable
                potion_types = ["Health", "Mana", "Strength", "Dexterity"]
                name = f"{random.choice(potion_types)} Potion"
                value = random.randint(10, 25)
            
            item = {
                "name": name,
                "type": item_type,
                "value": value
            }
            
            gold = random.randint(5, 15) * player.level
            
            return {
                "type": "treasure",
                "item": item,
                "gold": gold
            }
        elif event_type == "trap":
            trap_types = [
                {
                    "name": "Pit Trap",
                    "description": "You feel the ground give way beneath you as you fall into a hidden pit!",
                    "damage": random.randint(2, 5) * player.level // 2
                },
                {
                    "name": "Poison Dart Trap",
                    "description": "A dart shoots out from the wall and grazes your skin. You feel poison entering your bloodstream!",
                    "damage": random.randint(1, 3) * player.level
                },
                {
                    "name": "Collapsing Ceiling",
                    "description": "You hear a rumbling from above as rocks start to fall!",
                    "damage": random.randint(3, 6) * player.level // 2
                }
            ]
            
            trap = random.choice(trap_types)
            return {
                "type": "trap",
                **trap
            }
        elif event_type == "npc":
            npc_types = [
                {
                    "name": "Old Man",
                    "dialogue": "Beware the depths of the cave, young adventurer. Many have entered, few have returned."
                },
                {
                    "name": "Wandering Merchant",
                    "dialogue": "Ah, a customer! I'd offer to sell you something, but the developer hasn't implemented a shop system yet!"
                },
                {
                    "name": "Lost Child",
                    "dialogue": "Have you seen my parents? I got separated from them in the woods.",
                    "quest": {
                        "name": "Find the Lost Child's Parents",
                        "description": "Help the lost child find their parents in the town."
                    }
                },
                {
                    "name": "Mysterious Stranger",
                    "dialogue": "The ancient temple holds secrets of great power... and great danger."
                }
            ]
            
            npc = random.choice(npc_types)
            return {
                "type": "npc",
                **npc
            }
