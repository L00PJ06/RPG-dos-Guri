"""
Character classes for the RPG game.
"""
from game.dice import Dice
from game.inventory import Inventory

class Character:
    """Base character class for player and enemies."""
    
    def __init__(self, name, character_class="Unknown"):
        self.name = name
        self.character_class = character_class
        self.level = 1
        self.experience = 0
        self.health = 0
        self.max_health = 0
        self.mana = 0
        self.max_mana = 0
        self.strength = 0
        self.dexterity = 0
        self.intelligence = 0
        self.constitution = 0
        self.attack_dice = None
        self.defense_dice = None
        self.skills = []
        
    def is_alive(self):
        """Check if character is alive."""
        return self.health > 0
        
    def take_damage(self, amount):
        """Apply damage to the character."""
        self.health -= amount
        if self.health < 0:
            self.health = 0
        return amount
    
    def heal(self, amount):
        """Heal the character."""
        self.health += amount
        if self.health > self.max_health:
            self.health = self.max_health
        return amount
    
    def gain_experience(self, amount):
        """Gain experience points."""
        self.experience += amount
        # Check for level up
        exp_needed = self.level * 100
        if self.experience >= exp_needed:
            self.level_up()
            return True
        return False
    
    def level_up(self):
        """Level up the character."""
        self.level += 1
        self.max_health += 5 + (self.constitution // 2)
        self.health = self.max_health
        self.max_mana += 5 + (self.intelligence // 2)
        self.mana = self.max_mana
        
        # Additional stats based on class
        if self.character_class == "Warrior":
            self.strength += 2
            self.constitution += 1
        elif self.character_class == "Mage":
            self.intelligence += 2
            self.mana += 5
        elif self.character_class == "Rogue":
            self.dexterity += 2
            self.strength += 1
            
        return self.level

class Player(Character):
    """Player character class."""
    
    def __init__(self, name, character_class):
        super().__init__(name, character_class)
        self.inventory = Inventory()
        self.gold = 10
        self.location = "town"  # Starting location
        
        # Set base stats based on class
        if character_class == "Warrior":
            self.max_health = 25
            self.health = 25
            self.max_mana = 5
            self.mana = 5
            self.strength = 8
            self.dexterity = 4
            self.intelligence = 2
            self.constitution = 6
            self.attack_dice = Dice(10)  # d10
            self.defense_dice = Dice(8)  # d8
            self.skills = ["Slash", "Shield Bash"]
            
        elif character_class == "Mage":
            self.max_health = 15
            self.health = 15
            self.max_mana = 25
            self.mana = 25
            self.strength = 2
            self.dexterity = 4
            self.intelligence = 8
            self.constitution = 3
            self.attack_dice = Dice(6)  # d6
            self.defense_dice = Dice(4)  # d4
            self.skills = ["Fireball", "Frost Nova"]
            
        elif character_class == "Rogue":
            self.max_health = 18
            self.health = 18
            self.max_mana = 15
            self.mana = 15
            self.strength = 4
            self.dexterity = 8
            self.intelligence = 4
            self.constitution = 4
            self.attack_dice = Dice(8)  # d8
            self.defense_dice = Dice(6)  # d6
            self.skills = ["Backstab", "Stealth"]
    
    def to_dict(self):
        """Convert player to dictionary for saving."""
        return {
            "name": self.name,
            "character_class": self.character_class,
            "level": self.level,
            "experience": self.experience,
            "health": self.health,
            "max_health": self.max_health,
            "mana": self.mana,
            "max_mana": self.max_mana,
            "strength": self.strength,
            "dexterity": self.dexterity,
            "intelligence": self.intelligence,
            "constitution": self.constitution,
            "gold": self.gold,
            "location": self.location,
            "inventory": self.inventory.to_dict()
        }
    
    @classmethod
    def from_dict(cls, data):
        """Create player from dictionary."""
        player = cls(data["name"], data["character_class"])
        player.level = data["level"]
        player.experience = data["experience"]
        player.health = data["health"]
        player.max_health = data["max_health"]
        player.mana = data["mana"]
        player.max_mana = data["max_mana"]
        player.strength = data["strength"]
        player.dexterity = data["dexterity"]
        player.intelligence = data["intelligence"]
        player.constitution = data["constitution"]
        player.gold = data["gold"]
        player.location = data["location"]
        player.inventory = Inventory.from_dict(data["inventory"])
        
        # Restore dice objects based on class
        if player.character_class == "Warrior":
            player.attack_dice = Dice(10)
            player.defense_dice = Dice(8)
            player.skills = ["Slash", "Shield Bash"]
        elif player.character_class == "Mage":
            player.attack_dice = Dice(6)
            player.defense_dice = Dice(4)
            player.skills = ["Fireball", "Frost Nova"]
        elif player.character_class == "Rogue":
            player.attack_dice = Dice(8)
            player.defense_dice = Dice(6)
            player.skills = ["Backstab", "Stealth"]
            
        return player
