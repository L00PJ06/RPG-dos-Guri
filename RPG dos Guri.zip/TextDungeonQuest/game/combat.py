"""
Combat system for the RPG game.
"""
import random
import time
from game.dice import Dice

class Combat:
    """Handles combat between player and enemies."""
    
    def __init__(self, player, enemy, ui):
        self.player = player
        self.enemy = enemy
        self.ui = ui
        self.round = 1
        self.combat_log = []
        
    def start_combat(self):
        """Begin the combat sequence."""
        self.ui.display_message(f"\nA {self.enemy.name} appears!")
        self.ui.display_message(f"Combat begins! Get ready to fight.")
        
        # Initiative roll to determine who goes first
        player_initiative = Dice(20).roll() + (self.player.dexterity // 2)
        enemy_initiative = Dice(20).roll() + (self.enemy.dexterity // 2)
        
        if player_initiative >= enemy_initiative:
            self.ui.display_message("You have the initiative!")
            player_first = True
        else:
            self.ui.display_message(f"The {self.enemy.name} has the initiative!")
            player_first = False
            
        # Combat loop
        while self.player.is_alive() and self.enemy.is_alive():
            self.ui.display_message(f"\n--- Round {self.round} ---")
            self.ui.display_message(f"You: {self.player.health}/{self.player.max_health} HP")
            self.ui.display_message(f"{self.enemy.name}: {self.enemy.health}/{self.enemy.max_health} HP")
            
            if player_first:
                self._player_turn()
                if not self.enemy.is_alive():
                    break
                self._enemy_turn()
            else:
                self._enemy_turn()
                if not self.player.is_alive():
                    break
                self._player_turn()
                
            self.round += 1
        
        # Combat results
        if self.player.is_alive():
            exp_gain = self.enemy.level * 20
            gold_gain = random.randint(self.enemy.level, self.enemy.level * 5)
            
            self.ui.display_message(f"\nVictory! You defeated the {self.enemy.name}.")
            self.ui.display_message(f"You gained {exp_gain} experience and {gold_gain} gold.")
            
            level_up = self.player.gain_experience(exp_gain)
            self.player.gold += gold_gain
            
            if level_up:
                self.ui.display_message(f"Level up! You are now level {self.player.level}.")
                
            # Random item drop chance
            if random.random() < 0.3:  # 30% chance of item drop
                item_type = random.choice(["weapon", "armor", "potion"])
                item_quality = random.choice(["common", "uncommon", "rare"])
                item_level = max(1, self.enemy.level - 1)
                
                if item_type == "weapon":
                    item_name = f"{item_quality.capitalize()} Sword (Lvl {item_level})"
                    item = {"name": item_name, "type": "weapon", "value": 5 * item_level}
                elif item_type == "armor":
                    item_name = f"{item_quality.capitalize()} Armor (Lvl {item_level})"
                    item = {"name": item_name, "type": "armor", "value": 3 * item_level}
                else:  # potion
                    item_name = f"Health Potion"
                    item = {"name": item_name, "type": "consumable", "value": 10 * item_level}
                
                self.ui.display_message(f"The {self.enemy.name} dropped: {item_name}")
                self.player.inventory.add_item(item)
                
            return True
        else:
            self.ui.display_message(f"\nDefeat! You were defeated by the {self.enemy.name}.")
            self.ui.display_message("Game over.")
            return False
    
    def _player_turn(self):
        """Handle player's turn in combat."""
        self.ui.display_message("\nYour turn:")
        
        # Show available actions
        actions = ["Attack", "Use Skill", "Use Item", "Try to Flee"]
        action = self.ui.combat_menu(actions)
        
        if action == "1":  # Attack
            self._player_attack()
        elif action == "2":  # Use Skill
            if not self.player.skills:
                self.ui.display_message("You don't have any skills yet.")
                return self._player_turn()
            
            skill = self.ui.choose_skill(self.player.skills)
            if skill:
                self._player_use_skill(skill)
            else:
                return self._player_turn()
                
        elif action == "3":  # Use Item
            if not self.player.inventory.items:
                self.ui.display_message("Your inventory is empty.")
                return self._player_turn()
                
            item = self.ui.choose_item(self.player.inventory.items)
            if item:
                self._player_use_item(item)
            else:
                return self._player_turn()
                
        elif action == "4":  # Try to Flee
            flee_roll = Dice(20).roll() + (self.player.dexterity // 2)
            enemy_roll = Dice(20).roll() + (self.enemy.dexterity // 2)
            
            if flee_roll > enemy_roll:
                self.ui.display_message("You successfully fled from combat!")
                self.enemy.health = 0  # End combat without killing enemy
            else:
                self.ui.display_message("You failed to flee!")
    
    def _enemy_turn(self):
        """Handle enemy's turn in combat."""
        self.ui.display_message(f"\n{self.enemy.name}'s turn:")
        time.sleep(1)
        
        # Simple AI for enemy
        if self.enemy.health < self.enemy.max_health // 3 and random.random() < 0.3:
            # Enemy has a 30% chance to try to heal when below 1/3 health
            heal_amount = self.enemy.heal(self.enemy.level * 3)
            self.ui.display_message(f"The {self.enemy.name} heals for {heal_amount} health!")
        else:
            # Regular attack
            attack_roll = self.enemy.attack_dice.roll() + (self.enemy.strength // 2)
            defense_roll = self.player.defense_dice.roll() + (self.player.dexterity // 2)
            
            if attack_roll > defense_roll:
                damage = max(1, attack_roll - defense_roll)
                damage_dealt = self.player.take_damage(damage)
                self.ui.display_message(f"The {self.enemy.name} hits you for {damage_dealt} damage!")
            else:
                self.ui.display_message(f"The {self.enemy.name} misses you!")
    
    def _player_attack(self):
        """Handle player's basic attack."""
        attack_roll = self.player.attack_dice.roll() + (self.player.strength // 2)
        defense_roll = self.enemy.defense_dice.roll() + (self.enemy.dexterity // 2)
        
        self.ui.display_message(f"You roll {attack_roll} for attack.")
        self.ui.display_message(f"Enemy rolls {defense_roll} for defense.")
        
        if attack_roll > defense_roll:
            damage = max(1, attack_roll - defense_roll)
            damage_dealt = self.enemy.take_damage(damage)
            self.ui.display_message(f"You hit the {self.enemy.name} for {damage_dealt} damage!")
        else:
            self.ui.display_message(f"You miss the {self.enemy.name}!")
    
    def _player_use_skill(self, skill):
        """Handle player's skill usage."""
        # Check if player has enough mana
        mana_cost = 5
        if self.player.mana < mana_cost:
            self.ui.display_message(f"Not enough mana to use {skill}!")
            return self._player_turn()
            
        self.player.mana -= mana_cost
        
        # Skill effects based on class and skill name
        if self.player.character_class == "Warrior":
            if skill == "Slash":
                attack_roll = self.player.attack_dice.roll() + self.player.strength
                defense_roll = self.enemy.defense_dice.roll() + (self.enemy.dexterity // 2)
                
                if attack_roll > defense_roll:
                    damage = max(1, (attack_roll - defense_roll) * 1.5)  # 50% more damage
                    damage_dealt = int(self.enemy.take_damage(damage))
                    self.ui.display_message(f"You slash the {self.enemy.name} for {damage_dealt} damage!")
                else:
                    self.ui.display_message(f"Your slash misses the {self.enemy.name}!")
                    
            elif skill == "Shield Bash":
                attack_roll = self.player.attack_dice.roll() + (self.player.constitution // 2)
                defense_roll = self.enemy.defense_dice.roll() + (self.enemy.strength // 2)
                
                if attack_roll > defense_roll:
                    damage = max(1, attack_roll - defense_roll)
                    damage_dealt = self.enemy.take_damage(damage)
                    self.ui.display_message(f"You bash the {self.enemy.name} with your shield for {damage_dealt} damage!")
                    self.ui.display_message(f"The {self.enemy.name} is stunned for a turn!")
                    # Skip enemy's next turn
                    self._player_turn()
                else:
                    self.ui.display_message(f"Your shield bash missed the {self.enemy.name}!")
                    
        elif self.player.character_class == "Mage":
            if skill == "Fireball":
                attack_roll = Dice(10).roll() + self.player.intelligence
                defense_roll = self.enemy.defense_dice.roll() + (self.enemy.constitution // 2)
                
                if attack_roll > defense_roll:
                    damage = max(1, attack_roll + (self.player.intelligence // 2))
                    damage_dealt = self.enemy.take_damage(damage)
                    self.ui.display_message(f"Your fireball hits the {self.enemy.name} for {damage_dealt} damage!")
                else:
                    self.ui.display_message(f"Your fireball misses the {self.enemy.name}!")
                    
            elif skill == "Frost Nova":
                attack_roll = Dice(8).roll() + self.player.intelligence
                defense_roll = self.enemy.defense_dice.roll() + (self.enemy.constitution // 2)
                
                if attack_roll > defense_roll:
                    damage = max(1, attack_roll - defense_roll)
                    damage_dealt = self.enemy.take_damage(damage)
                    self.ui.display_message(f"Your frost nova hits the {self.enemy.name} for {damage_dealt} damage!")
                    self.ui.display_message(f"The {self.enemy.name} is frozen for a turn!")
                    # Skip enemy's next turn
                    self._player_turn()
                else:
                    self.ui.display_message(f"Your frost nova had no effect on the {self.enemy.name}!")
                    
        elif self.player.character_class == "Rogue":
            if skill == "Backstab":
                attack_roll = self.player.attack_dice.roll() + self.player.dexterity
                defense_roll = self.enemy.defense_dice.roll() + (self.enemy.dexterity // 2)
                
                if attack_roll > defense_roll:
                    damage = max(1, (attack_roll - defense_roll) * 2)  # Double damage
                    damage_dealt = int(self.enemy.take_damage(damage))
                    self.ui.display_message(f"Your backstab critically hits the {self.enemy.name} for {damage_dealt} damage!")
                else:
                    self.ui.display_message(f"Your backstab attempt failed!")
                    
            elif skill == "Stealth":
                stealth_roll = Dice(20).roll() + self.player.dexterity
                detection_roll = Dice(20).roll() + (self.enemy.intelligence // 2)
                
                if stealth_roll > detection_roll:
                    self.ui.display_message(f"You vanish into the shadows! The {self.enemy.name} can't find you.")
                    self.ui.display_message(f"You prepare a deadly strike...")
                    # Get a free attack next turn with bonus damage
                    attack_roll = self.player.attack_dice.roll() * 2 + self.player.dexterity
                    damage = max(1, attack_roll)
                    damage_dealt = self.enemy.take_damage(damage)
                    self.ui.display_message(f"You strike from the shadows dealing {damage_dealt} damage!")
                else:
                    self.ui.display_message(f"The {self.enemy.name} spots you trying to hide!")
    
    def _player_use_item(self, item):
        """Handle player's item usage."""
        if item["type"] == "consumable":
            if "Health Potion" in item["name"]:
                heal_amount = 10 * (self.player.level // 2 + 1)
                actual_heal = self.player.heal(heal_amount)
                self.ui.display_message(f"You drink a Health Potion and restore {actual_heal} health!")
                self.player.inventory.remove_item(item)
            elif "Mana Potion" in item["name"]:
                mana_amount = 10 * (self.player.level // 2 + 1)
                self.player.mana = min(self.player.max_mana, self.player.mana + mana_amount)
                self.ui.display_message(f"You drink a Mana Potion and restore {mana_amount} mana!")
                self.player.inventory.remove_item(item)
            else:
                self.ui.display_message(f"You can't use {item['name']} in combat.")
                return self._player_turn()
        else:
            self.ui.display_message(f"You can't use {item['name']} in combat.")
            return self._player_turn()
