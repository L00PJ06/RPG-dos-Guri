"""
Dice rolling system for the RPG game.
"""
import random

class Dice:
    """Class to represent a dice with a specific number of sides."""
    
    def __init__(self, sides):
        """Initialize a dice with the specified number of sides."""
        self.sides = sides
    
    def roll(self, num_rolls=1):
        """
        Roll the dice a specified number of times.
        
        Args:
            num_rolls (int): Number of times to roll the dice.
            
        Returns:
            int: The sum of all dice rolls.
        """
        total = 0
        for _ in range(num_rolls):
            total += random.randint(1, self.sides)
        return total
    
    def __str__(self):
        """String representation of the dice."""
        return f"d{self.sides}"

# Common dice types
d4 = Dice(4)
d6 = Dice(6)
d8 = Dice(8)
d10 = Dice(10)
d12 = Dice(12)
d20 = Dice(20)
