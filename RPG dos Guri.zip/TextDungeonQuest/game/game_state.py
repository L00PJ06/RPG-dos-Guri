"""
Game state management for the RPG game.
"""
import os
import json
import glob
from datetime import datetime
from game.character import Player
from game.inventory import Inventory

class GameState:
    """Manages the state of the game, including saving and loading."""
    
    def __init__(self):
        """Initialize a new game state."""
        self.player = None
        self.save_dir = "saves"
        self.current_save = None
    
    def save_game(self, save_name):
        """
        Save the current game state.
        
        Args:
            save_name (str): Name for the save file.
        """
        if not self.player:
            return False
        
        # Create saves directory if it doesn't exist
        os.makedirs(self.save_dir, exist_ok=True)
        
        # Generate timestamp for save file
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{save_name}_{timestamp}.json"
        save_path = os.path.join(self.save_dir, filename)
        
        # Create save data
        save_data = {
            "save_name": save_name,
            "timestamp": timestamp,
            "player": self.player.to_dict()
        }
        
        # Write save file
        try:
            with open(save_path, 'w') as f:
                json.dump(save_data, f, indent=2)
            self.current_save = save_path
            return True
        except Exception as e:
            print(f"Error saving game: {e}")
            return False
    
    def load_game(self, save_path):
        """
        Load a game from a save file.
        
        Args:
            save_path (str): Path to the save file.
        """
        try:
            with open(save_path, 'r') as f:
                save_data = json.load(f)
            
            self.player = Player.from_dict(save_data["player"])
            self.current_save = save_path
            return True
        except Exception as e:
            print(f"Error loading game: {e}")
            return False
    
    def get_save_files(self):
        """
        Get a list of available save files.
        
        Returns:
            list: List of save file paths.
        """
        os.makedirs(self.save_dir, exist_ok=True)
        save_pattern = os.path.join(self.save_dir, "*.json")
        return glob.glob(save_pattern)
    
    def get_save_info(self, save_path):
        """
        Get information about a save file.
        
        Args:
            save_path (str): Path to the save file.
            
        Returns:
            dict: Information about the save file, or None if there was an error.
        """
        try:
            with open(save_path, 'r') as f:
                save_data = json.load(f)
            
            player_data = save_data["player"]
            return {
                "save_name": save_data.get("save_name", "Unknown"),
                "timestamp": save_data.get("timestamp", "Unknown"),
                "player_name": player_data.get("name", "Unknown"),
                "player_class": player_data.get("character_class", "Unknown"),
                "player_level": player_data.get("level", 1)
            }
        except Exception as e:
            print(f"Error reading save file {save_path}: {e}")
            return None
